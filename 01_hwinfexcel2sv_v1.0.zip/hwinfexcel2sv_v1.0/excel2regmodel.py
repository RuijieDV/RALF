#!/usr/bin/python3
# -*- coding: UTF-8 -*-
from pandas import Series, DataFrame
import pandas as pd
#import numpy as np
from math import isnan
#from openpyxl import Workbook
#from openpyxl import load_workbook
#from openpyxl.utils.dataframe import dataframe_to_rows
#from openpyxl.styles import Font, colors, Border,Side, Alignment, PatternFill
#import xlwings as xw
#import os

field_title = ["name", "size", "pos", "acc", "reset"]
reg_title   = ["name", "addr", "acc"]


reg_sht_title = ['Bit','Field','Access','ResetVal','Description']
filename = './HW_inf_specification.xlsx'
rm_filename = './reg_model.sv'

def write_uvm_reg(fd,f_item,reg_info,reg_width):
    wr_lines = []
    wr_lines.append("\nclass %s extends uvm_reg;\n"%(reg_info[0]))

    #f_item format: [fieldname, size, lsb_pos, access, resetval]
    for i in range(len(f_item)):
        wr_lines.append("  rand uvm_reg_field %s;\n"%(f_item[i][0]))

    wr_lines.append("\n  function new(string name = \"%s\");\n"%(reg_info[0]))
    wr_lines.append("    super.new(name, %d,build_coverage(UVM_NO_COVERAGE));\n"%(reg_width*8))
    wr_lines.append("  endfunction\n")

    wr_lines.append("\n  virtual function void build();\n")
    for i in range(len(f_item)):
        wr_lines.append("    %s = uvm_reg_field::type_id::create(\"%s\");\n"%(f_item[i][0],f_item[i][0]))
        wr_lines.append("    %s.configure(this, %s, %s, \"%s\", 0, \'h%s, 1, 0, 0);\n"%
                          (f_item[i][0],f_item[i][1],f_item[i][2],f_item[i][3],f_item[i][4][2:]))
    wr_lines.append("  endfunction\n")

    wr_lines.append("\n  `uvm_object_utils(%s)\n"%(reg_info[0]))

    wr_lines.append("\nendclass : %s\n"%(reg_info[0]))
    fd.writelines(wr_lines)


def write_uvm_reg_block(fd,reg_list,base_addr,reg_width):
    wr_lines = []
    wr_lines.append("class reg_model extends uvm_reg_block;\n")

    for i in range(len(reg_list)):
        #reglist format: [name, offset, access, resetval, reg_repeatcnt, block_repeat_cnt, block_size]
        #如果block需要重复定义
        if reg_list[i][5]>1:
            for blkcnt in range(reg_list[i][5]):
                #寄存器需要重复
                if reg_list[i][4]>1:
                    for j in range(reg_list[i][4]):
                        wr_lines.append("  rand %s  reg_%s_%d_%d;\n"%(reg_list[i][0],reg_list[i][0],blkcnt, j))
                #寄存器不需要重复
                else:
                    wr_lines.append("  rand %s  reg_%s_%d;\n"%(reg_list[i][0],reg_list[i][0],blkcnt))
        #block不需要重复定义
        else:
            if reg_list[i][4]>1:
                for j in range(reg_list[i][4]):
                    wr_lines.append("  rand %s  reg_%s_%d;\n"%(reg_list[i][0],reg_list[i][0],j))
            else:
                wr_lines.append("  rand %s  reg_%s;\n"%(reg_list[i][0],reg_list[i][0]))            

    wr_lines.append("\n  function new(string name = \"reg_model\");\n")
    wr_lines.append("    super.new(name, UVM_NO_COVERAGE);\n")
    wr_lines.append("  endfunction\n")

    wr_lines.append("\n  virtual function void build();\n")
    wr_lines.append("    default_map = create_map(\"default_map\", \'h%s, %d, UVM_LITTLE_ENDIAN, 0);\n\n"%(hex(base_addr)[2:],reg_width))

    for i in range(len(reg_list)):
        #reglist format: [name, offset, access, resetval, reg_repeatcnt, block_repeat_cnt, block_size]
        #如果block需要重复定义
        if reg_list[i][5]>1:
            for blkcnt in range(reg_list[i][5]):
                if reg_list[i][4]>1:
                    for j in range(reg_list[i][4]):
                        reg_name = "reg_%s_%d_%d"%(reg_list[i][0],blkcnt,j)
                        reg_offset = hex(int(reg_list[i][1].split("-")[0],16) + blkcnt*reg_list[i][6] + j*reg_width)
                        wr_lines.append("    %s = %s::type_id::create(\"%s\");\n"%(reg_name, reg_list[i][0],reg_name))
                        wr_lines.append("    %s.configure(this, null, \"\");\n"%(reg_name))
                        wr_lines.append("    %s.build();\n"%(reg_name))
                        wr_lines.append("    default_map.add_reg(%s, \'h%s, \"%s\");\n\n"%(reg_name, reg_offset[2:], reg_list[i][2]))
                else:
                    reg_name = "reg_%s_%d"%(reg_list[i][0],blkcnt)
                    reg_offset = hex(int(reg_list[i][1],16) + blkcnt*reg_list[i][6])
                    wr_lines.append("    %s = %s::type_id::create(\"%s\");\n"%(reg_name, reg_list[i][0],reg_name))
                    wr_lines.append("    %s.configure(this, null, \"\");\n"%(reg_name))
                    wr_lines.append("    %s.build();\n"%(reg_name))
                    wr_lines.append("    default_map.add_reg(%s, \'h%s, \"%s\");\n\n"%(reg_name,reg_offset[2:], reg_list[i][2]))
        #block不需要重复定义
        else:
            if reg_list[i][4]>1:
                for j in range(reg_list[i][4]):
                    reg_name = "reg_%s_%d"%(reg_list[i][0],j)
                    reg_offset = hex(int(reg_list[i][1].split("-")[0],16) + j*reg_width)
                    wr_lines.append("    %s = %s::type_id::create(\"%s\");\n"%(reg_name, reg_list[i][0],reg_name))
                    wr_lines.append("    %s.configure(this, null, \"\");\n"%(reg_name))
                    wr_lines.append("    %s.build();\n"%(reg_name))
                    wr_lines.append("    default_map.add_reg(%s, \'h%s, \"%s\");\n\n"%(reg_name, reg_offset[2:], reg_list[i][2]))
            else:
                reg_name = "reg_%s"%(reg_list[i][0])
                wr_lines.append("    %s = %s::type_id::create(\"%s\");\n"%(reg_name, reg_list[i][0],reg_name))
                wr_lines.append("    %s.configure(this, null, \"\");\n"%(reg_name))
                wr_lines.append("    %s.build();\n"%(reg_name))
                wr_lines.append("    default_map.add_reg(%s, \'h%s, \"%s\");\n\n"%(reg_name,reg_list[i][1][2:], reg_list[i][2]))

    wr_lines.append("  endfunction\n")
    wr_lines.append("\n  `uvm_object_utils(%s)\n"%("reg_model"))
    wr_lines.append("\nendclass : %s\n"%("reg_model"))
    wr_lines.append("`endif\n")
    fd.writelines(wr_lines)


#从各个sheet生成regmodel(reg,field,block)
def exact_reg_info(reg_list,reg_sht_name,blk_rpt_cnt,blk_size,reg_width,fd):
    for i in range(len(reg_sht_name)):
        df = pd.read_excel(filename,sheetname=reg_sht_name[i],
                           header=None,names=reg_sht_title)
        #删除Description列，
        del df['Description']
        #删除空行
        df.dropna(axis=0, how='all', inplace=True)
        df.index = list(range(len(df)))
        #各个寄存器分界线
        reg_div = df[(df.Bit=='RegName:')].index.tolist()
        for k in range(len(reg_div)):
            if k == len(reg_div)-1:
                reglinerange = [reg_div[k],len(df)-1]
            else:
                reglinerange = [reg_div[k],reg_div[k+1]-1]
            #根据分界线取出reg定义部分
            reg_df = df.iloc[reglinerange[0]:reglinerange[1]+1]
            #找offset=xxx~xxx的寄存器，计算此寄存器需要重复几遍
            if reg_df.iloc[1].values[1].find('-')!=-1 :
                reg_ext_sta = int(reg_df.iloc[1].values[1].split("-")[0],16)
                reg_ext_end = int(reg_df.iloc[1].values[1].split("-")[1],16) | (reg_width-1)
                reg_rpt_cnt = int((reg_ext_end-reg_ext_sta+1)/4)
                reg_name    = reg_df.iloc[0].values[1].split("-")[0][:-1]
            else:
                reg_rpt_cnt = 1
                reg_name    = reg_df.iloc[0].values[1]
            #reg名字,offset,reset值,重复次数 添加到reg_list列表中
            #[name, offset, resetval, repeatcnt]
            reg_info = [reg_name,                   #name
                        reg_df.iloc[1].values[1],   #offset
                        reg_df.iloc[2].values[1],   #access
                        reg_df.iloc[3].values[1],   #resetval
                        reg_rpt_cnt,                #reg repeat cnt
                        blk_rpt_cnt[i],             #block repeat cnt
                        blk_size[i]]                #block size
            reg_list.append(reg_info)
            #reg_df只保留bit信息
            reg_df.dropna(inplace=True)
            reg_df.index = list(range(len(reg_df)))
            reg_df.drop([0],axis=0, inplace=True)
            reg_df.index = list(range(len(reg_df)))
            #提取bit信息
            f_item = []
            if len(reg_df)>0 :
                for item in reg_df.values: #[bit, fieldname, access, resetval]
                    #计算field的size，lsb pos
                    if item[0].find(':')!=-1 :
                       lsb_pos = item[0].split(":")[1]
                       f_size  = "%d"%(int(item[0].split(":")[0]) - int(item[0].split(":")[1]) + 1)
                    else:
                       lsb_pos = item[0]
                       f_size  = '1'
                    #转换为[fieldname, size, lsb_pos, access, resetval]
                    f_item.append([item[1], f_size, lsb_pos, item[2], item[3]])
            else:
                #如果excel上未设定bit，那么使用default值
                #[fieldname, size, lsb_pos, access, resetval]
                f_item = [["reg_data", '32', '0', reg_info[2], reg_info[3]]]
            #print(f_item)
            # gen uvm_reg to sv file
            write_uvm_reg(fd,f_item,reg_info,reg_width)


def main():
    "Function main(): execute py from here"
    print('*************************************************************************')
    print('---------Generate reg_model.sv by PYTHON3 automatically (start)---------')
    print('*************************************************************************')
    reg_list = []
    blk_size = []
    df = pd.read_excel(filename,sheetname='summary', header=0)
    #取出寄存器width设置
    reg_width = int(df[(df.Offset=='Width(Byte)')]['Name'].values.tolist()[0])
    #查找寄存器定义各个sheet的名字
    reg_sht_name = df[(df.Offset=='BlockName') & (df.Description!='Ignore_details')]['Name'].values.tolist()
    reg_used_index = df[(df.Offset=='BlockName') & (df.Description!='Ignore_details')].index.tolist()
    #计算每个模块的寄存器空间的size
    for i in range(len(reg_used_index)):
        get_size = df.iloc[reg_used_index[i]-2].values[1]
        blk_sta = int(get_size.split('-')[0],16)
        blk_end = int(get_size.split('-')[1],16) | (reg_width-1)
        blk_size.append(int(blk_end-blk_sta+1))
    print(blk_size)
    print(reg_sht_name)
    #查找模块寄存器重复次数
    blk_rpt_cnt = df[(df.Offset=='BlockName') & (df.Description!='Ignore_details')]['Description'].values.tolist()
    for i in range(len(blk_rpt_cnt)):
        if str(blk_rpt_cnt[i])=='nan':
            blk_rpt_cnt[i] = 1
        else:
            if blk_rpt_cnt[i].find('RepeatCnt')!=-1:
                blk_rpt_cnt[i] = int(blk_rpt_cnt[i].split(':')[1])
            else:
                blk_rpt_cnt[i] = 1
    print(blk_rpt_cnt)
    #提取fpga base addr
    df = pd.read_excel(filename,sheetname='SpaceAlignment', header=None)
    base_addr = df.iloc[0].values[1]
    if isnan(df.iloc[0].values[1]) :
        base_addr = 0
    else:
        base_addr = int(df.iloc[0].values[1],16)
    #创建reg_model.sv，并写入寄存器定义
    #print(os.getcwd())
    fd = open(rm_filename, "w")
    fd.write('`ifndef REG_MODEL__SV\n')
    fd.write('`define REG_MODEL__SV\n\n')
    #提取excel信息，并定义uvm_reg
    exact_reg_info(reg_list,reg_sht_name,blk_rpt_cnt,blk_size,reg_width,fd)
    #print(reg_list)
    #定义uvm_reg_block
    write_uvm_reg_block(fd,reg_list,base_addr,reg_width)
    
    fd.close()

    print('*************************************************************************')
    print('---------Generate reg_model.sv by PYTHON3 automatically (end)-----------')
    print('*************************************************************************')


if __name__ == '__main__':
    main()



