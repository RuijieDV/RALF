#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from pandas import Series, DataFrame
import pandas as pd
#import numpy as np
#from math import isnan
#from openpyxl import Workbook
from openpyxl import load_workbook
#from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, colors, Border,Side, Alignment, PatternFill
from openpyxl.comments import Comment

bittitle = ['Bit','Field','Access','ResetVal','Description']
bold_font = Font(name='等线', size=11, bold=True)
fill_darkgreen = PatternFill(fill_type='solid',start_color='E5FEFF',end_color='E5FEFF')
fill_white = PatternFill(fill_type='solid',start_color='FFFFFF',end_color='FFFFFF')
fill_yellow = PatternFill(fill_type='solid',start_color='FFFF00',end_color='FFFF00')
filename = './HW_inf_specification.xlsx'
# border1 = Border(left=Side(style='medium'),
                     # right=Side(style='thin'),
                     # top=Side(style='thin'),
                     # bottom=Side(style='thin'))


def reg_filed_style(ws,cur_line):
    obj_cell_1 = "%s%d" % ('A', cur_line)
    ws[obj_cell_1].font =  bold_font
    for j in range(5):
        ws.cell(row=cur_line,column=j+1).fill = fill_darkgreen


def bit_filed_style(ws,cur_line,lastone):
    if lastone==False:
        for j in range(5):
            ws.cell(row=cur_line,column=j+1).fill = fill_white
            if j==0:
                ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='medium'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
            elif j==4:
                ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='thin'), right=Side(style='medium'), top=Side(style='thin'), bottom=Side(style='thin'))
            else:
                ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    else:
        for j in range(5):
            ws.cell(row=cur_line,column=j+1).fill = fill_white
            if j==0:
                ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='medium'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='medium'))
            elif j==4:
                ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='thin'), right=Side(style='medium'), top=Side(style='thin'), bottom=Side(style='medium'))
            else:
                ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='medium'))


def reg_details(regno,reg_info,ws,cur_line,rptcnt):
    #生成register information(name, offset, resetvalue)
    ws.append(['RegName:',reg_info['Name'][regno]])
    cur_line = cur_line + 1
    reg_filed_style(ws,cur_line)
    for j in range(5):
        if j==0:
            ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='medium'), top=Side(style='medium'))
        elif j==4:
            ws.cell(row=cur_line,column=j+1).border = Border(right=Side(style='medium'), top=Side(style='medium'))
        else:
            ws.cell(row=cur_line,column=j+1).border = Border(top=Side(style='medium'))

    ws.append(['Offset:',reg_info['Offset'][regno]])
    cur_line = cur_line + 1
    reg_filed_style(ws,cur_line)
    for j in range(5):
        if j==0:
            ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='medium'))
        elif j==4:
            ws.cell(row=cur_line,column=j+1).border = Border(right=Side(style='medium'))

    ws.append(['Access:',reg_info['R/W'][regno]])
    cur_line = cur_line + 1
    reg_filed_style(ws,cur_line)
    for j in range(5):
        if j==0:
            ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='medium'))
        elif j==4:
            ws.cell(row=cur_line,column=j+1).border = Border(right=Side(style='medium'))
            
    ws.append(['Reset:',reg_info['Reset'][regno]])
    cur_line = cur_line + 1
    reg_filed_style(ws,cur_line)
    for j in range(5):
        if j==0:
            ws.cell(row=cur_line,column=j+1).border = Border(left=Side(style='medium'), bottom=Side(style='double'))
        elif j==4:
            ws.cell(row=cur_line,column=j+1).border = Border(right=Side(style='medium'), bottom=Side(style='double'))
        else:
            ws.cell(row=cur_line,column=j+1).border = Border(bottom=Side(style='double'))

    #生成bit information(作为模板，只生成4行bit域)
    ws.append(['Bit Details'])
    cur_line = cur_line + 1
    ws.cell(row=cur_line,column=1).border = Border(left=Side(style='medium'))
    ws.cell(row=cur_line,column=5).border = Border(right=Side(style='medium'))
    for j in range(5):
        ws.cell(row=cur_line,column=j+1).fill = fill_white
    #cell_sel = "%s%d:%s%d" % ('A', cur_line,'E', cur_line)
    #ws.merge_cells(cell_sel)

    ws.append(bittitle)
    cur_line = cur_line + 1
    bit_filed_style(ws,cur_line,False)

    for k in range(4):
        ws.append([])
        cur_line = cur_line + 1
        bit_filed_style(ws,cur_line,k==3)

    # fill blank line at last
    ws.append([])
    cur_line = cur_line + 1
    ws.append([])
    cur_line = cur_line + 1
    return cur_line


def gen_reg_detail(filename,wb,reg_info,base_add,sht_name,rptcnt):
    all_sheet_name = wb.get_sheet_names()
    if sht_name in all_sheet_name:
        wb.remove_sheet(wb.get_sheet_by_name(sht_name))
    ws = wb.create_sheet(sht_name)
    # generate the details of each register
    ws.column_dimensions['A'].width = 9.5
    ws.column_dimensions['B'].width = 20.5
    ws.column_dimensions['C'].width = 8.5
    ws.column_dimensions['D'].width = 15.5
    ws.column_dimensions['E'].width = 52.5
    # ws.append(["BaseAddr",base_add])
    # ws.append([])
    # cur_line = 2
    ws.append([])
    cur_line = 1
    for i in range(len(reg_info)):
        cur_line = reg_details(i,reg_info,ws,cur_line,rptcnt)


def create_spacealign_sheet(wb,blkarea,blkname,blkrptcnt,blkwidth):
    #创建寄存器空间分配sheet
    all_sheet_name = wb.get_sheet_names()
    sht_name = "SpaceAlignment"
    if sht_name in all_sheet_name:
        wb.remove_sheet(wb.get_sheet_by_name(sht_name))
    ws = wb.create_sheet(sht_name)
    #设置sheet格式
    ws.column_dimensions['A'].width = 16.5
    ws.column_dimensions['B'].width = 30.5
    #生成表头
    ws.append(["BaseAddr:"])
    ws.append([])
    ws.cell(row=1,column=2).fill = fill_yellow
    comment = Comment('设计者填写寄存器空间基地址','author')
    ws.cell(row=1,column=2).comment = comment  
    ws.append(["SpaceArea:","Description"])
    ws.cell(row=3,column=1).border = Border(left=Side(style='medium'), right=Side(style='thin'), top=Side(style='medium'), bottom=Side(style='medium'))
    ws.cell(row=3,column=2).border = Border(left=Side(style='thin'), right=Side(style='medium'), top=Side(style='medium'), bottom=Side(style='medium'))
    ws.cell(row=3,column=1).fill = fill_darkgreen
    ws.cell(row=3,column=2).fill = fill_darkgreen
    
    cur_line = 3
    for i in range(len(blkarea)):
        #如果该block的寄存器需要对各个port/channel重复定义
        # if blkrpt[i][0]!=blkrpt[i][1] :
        if blkrptcnt[i]!=0 :
            blk_sta = int(blkarea[i].split("-")[0],16)
            blk_end = int(blkarea[i].split("-")[1],16) | (blkwidth[i]-1)
            blk_size   = blk_end - blk_sta + 1
            rpt_append = list(range(blkrptcnt[i]))
            #生成空间分配信息
            for j in range(len(rpt_append)) :
                #如果需要重复定义，block名后面append上序号
                #item = str(rpt_append[j])
                if j==0 :
                    ws.append([blkarea[i],'%s_%d'%(blkname[i],rpt_append[j])])
                else :
                    blk_sta = blk_sta + blk_size
                    blk_end = blk_end + blk_size
                    ws.append(['%s-%s'%(hex(blk_sta), hex(blk_end)),'%s_%d'%(blkname[i],rpt_append[j])])
                cur_line = cur_line + 1
                ws.cell(row=cur_line,column=1).border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
                ws.cell(row=cur_line,column=2).border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        #如果不重复
        else :
            ws.append([blkarea[i],blkname[i]])
            cur_line = cur_line + 1
            ws.cell(row=cur_line,column=1).border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
            ws.cell(row=cur_line,column=2).border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

            
def main():
    "Function main(): execute py from here"
    print('*************************************************************************')
    print('---------Generate register info in excel by PYTHON3 automatically (start)---------')
    print('*************************************************************************')

    df = pd.read_excel(filename,sheetname='summary', header=0)
    #把df按block进行拆分
    #1.根据关键字‘AddrSpace’找出block的分界
    blk1stline = df[(df.Offset=='AddrSpace')].index.tolist()
    blklinerange = [[] for x in range(len(blk1stline))]
    for i in range(len(blk1stline)):
        if i == len(blk1stline)-1:
            blklinerange[i] = [blk1stline[i],len(df)-1]
        else:
            blklinerange[i] = [blk1stline[i],blk1stline[i+1]-1]
    
    #2.load excel to be written
    wb = load_workbook(filename)
    
    #3.拆分block
    blkarea = []
    blkname = []
    blkwidth = []
    blkrptcnt = []
    blkrpt  = [[0,0] for x in range(len(blk1stline))]
    for i in range(len(blklinerange)):
        #取出拆分的block
        blk_df = df.iloc[blklinerange[i][0]:blklinerange[i][1]+1]   
        #遇到不需要产生寄存器详细定义的部分时，跳出本次循环
        if blk_df.iloc[2].values[4]=="Ignore_details" :
            continue        
        #print(blk_df)
        #从AddrSpace取出base address
        blk_base_add = blk_df.iloc[0].values[1].split("-")[0]
        blkarea.append(blk_df.iloc[0].values[1])
        #从Width(Byte)取出reg width
        blkwidth.append(int(blk_df.iloc[1].values[1]))
        #从BlockName取出新建sheet的名字 & 该block需要重复的次数
        blkshtname = blk_df.iloc[2].values[1]
        if str(blk_df.iloc[2].values[4])=='nan':
            blkname.append(blk_df.iloc[2].values[1])
            curblk_rptcnt = 0
            blkrptcnt.append(curblk_rptcnt)
        else:
            if blk_df.iloc[2].values[4].find('RepeatCnt')!=-1 :
                blkname.append(blk_df.iloc[2].values[1][:-2])
                curblk_rptcnt = int(blk_df.iloc[2].values[4].split(':')[1])
                blkrptcnt.append(curblk_rptcnt)
            else :
                blkname.append(blk_df.iloc[2].values[1])
                curblk_rptcnt = 0
                blkrptcnt.append(curblk_rptcnt)
        
        #删除blk_df里面有NaN的行（只保留有效的寄存器信息）
        blk_df.dropna(inplace=True)
        #生成行索引
        blk_df.index = list(range(len(blk_df)))
        #生成寄存器详细sheet
        gen_reg_detail(filename,wb,blk_df,blk_base_add,blkshtname,curblk_rptcnt)
    
    #4.生成寄存器空间分配表
    create_spacealign_sheet(wb,blkarea,blkname,blkrptcnt,blkwidth)
    
    #5.save excel
    wb.save(filename)

    print('*************************************************************************')
    print('---------Generate register info in excel by PYTHON3 automatically (end)-----------')
    print('*************************************************************************')


if __name__ == '__main__':
    main()            
    

