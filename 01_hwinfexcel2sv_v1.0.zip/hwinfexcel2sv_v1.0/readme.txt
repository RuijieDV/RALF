============================================================================
FileName: hw_inf_excel.exe
Author: mali
Email: mli@ruijie.com.cn
Version: 1.0
LastChange: 2018-10-25
History: First edition
============================================================================
1. What is hw_inf_excel.exe?
   hw_inf_excel.exe is used to automatically generate the overview of register 
   space alignment, and create the templeate of register details from 'summary'
   sheet.

2. How does it work?
   Create the summary information of registers in 'summary' sheet(HW_inf_specification.xlsx),
   then double click hw_inf_excel.exe, you will get the updated HW_inf_specification.xlsx.
   Be sure that HW_inf_specification.xlsx is in the same fold with exe file.
   
============================================================================
FileName: excel2regmodel.exe
Author: mali
Email: mli@ruijie.com.cn
Version: 1.0
LastChange: 2018-10-25
History: First edition
============================================================================
1. What is excel2regmodel.exe?
   excel2regmodel.exe is used to automatically generate register define file of 
   UVM register model by HW_inf_specification.xlsx.

2. How does it work?
   Double click excel2regmodel.exe, then you will get reg_model.sv.
   Be sure that HW_inf_specification.xlsx is updated by hw_inf_excel.exe, 
   and it is in the same fold with exe file.